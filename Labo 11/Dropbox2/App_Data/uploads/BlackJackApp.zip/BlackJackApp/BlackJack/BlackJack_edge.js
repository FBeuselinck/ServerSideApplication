/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
            js+"jquery-2.1.1.min.js"
        ],
        symbols = {
            "stage": {
                version: "5.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.0.375",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'background',
                            type: 'image',
                            rect: ['0', '0', '550px', '400px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"background.jpg",'0px','0px']
                        },
                        {
                            id: 'Rectangle',
                            type: 'rect',
                            rect: ['1px', '0px', '549px', '60px', 'auto', 'auto'],
                            opacity: 0.5,
                            fill: ["rgba(0,0,0,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'scoreComputer',
                            type: 'text',
                            rect: ['0px', '0px', '96px', '60px', 'auto', 'auto'],
                            text: "00<br>",
                            align: "center",
                            font: ['Arial, Helvetica, sans-serif', [50, "px"], "rgba(255,255,255,1.00)", "normal", "none", "", "break-word", "normal"]
                        },
                        {
                            id: 'log',
                            type: 'text',
                            rect: ['95px', '0px', '359px', '60px', 'auto', 'auto'],
                            text: "Game not started",
                            align: "center",
                            font: ['Arial, Helvetica, sans-serif', [34, "px"], "rgba(255,255,255,1.00)", "500", "none", "", "break-word", "normal"],
                            textStyle: ["", "", "55px", ""]
                        },
                        {
                            id: 'scorePlayer',
                            type: 'text',
                            rect: ['454px', '0px', '96px', '60px', 'auto', 'auto'],
                            text: "00<br>",
                            align: "center",
                            font: ['Arial, Helvetica, sans-serif', [50, "px"], "rgba(255,255,255,1.00)", "normal", "none", "", "break-word", "normal"]
                        },
                        {
                            id: 'Deal',
                            symbolName: 'Deal',
                            type: 'rect',
                            rect: ['332px', '334px', '97', '61', 'auto', 'auto'],
                            opacity: 0.6,
                            transform: [[],[],[],['0.63019','0.63019']]
                        },
                        {
                            id: 'Fold',
                            symbolName: 'Fold',
                            type: 'rect',
                            rect: ['423px', '333px', '97', '62', 'auto', 'auto'],
                            opacity: 0.6,
                            transform: [[],[],[],['0.63019','0.63019']]
                        },
                        {
                            id: 'player',
                            symbolName: 'CardsContainer',
                            type: 'rect',
                            rect: ['303px', '60px', 'undefined', 'undefined', 'auto', 'auto'],
                            transform: [[],[],[],['0.90909','0.84746']]
                        },
                        {
                            id: 'computer',
                            symbolName: 'CardsContainer',
                            type: 'rect',
                            rect: ['18px', '70px', 'undefined', 'undefined', 'auto', 'auto'],
                            transform: [[],[],[],['0.90909','0.84746']]
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '550px', '400px', 'auto', 'auto'],
                            overflow: 'hidden',
                            fill: ["rgba(255,255,255,1)"]
                        }
                    }
                },
                timeline: {
                    duration: 0,
                    autoPlay: true,
                    data: [
                        [
                            "eid13",
                            "scaleY",
                            0,
                            0,
                            "linear",
                            "${Fold}",
                            '0.63019',
                            '0.63019'
                        ],
                        [
                            "eid15",
                            "top",
                            0,
                            0,
                            "linear",
                            "${Fold}",
                            '333px',
                            '333px'
                        ],
                        [
                            "eid17",
                            "left",
                            0,
                            0,
                            "linear",
                            "${Deal}",
                            '332px',
                            '332px'
                        ],
                        [
                            "eid54",
                            "rotateZ",
                            0,
                            0,
                            "linear",
                            "${player}",
                            '0deg',
                            '0deg'
                        ],
                        [
                            "eid8",
                            "scaleX",
                            0,
                            0,
                            "linear",
                            "${Deal}",
                            '0.63019',
                            '0.63019'
                        ],
                        [
                            "eid3",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${Fold}",
                            '0.6',
                            '0.6'
                        ],
                        [
                            "eid74",
                            "left",
                            0,
                            0,
                            "linear",
                            "${computer}",
                            '18px',
                            '18px'
                        ],
                        [
                            "eid16",
                            "left",
                            0,
                            0,
                            "linear",
                            "${Fold}",
                            '423px',
                            '423px'
                        ],
                        [
                            "eid12",
                            "scaleX",
                            0,
                            0,
                            "linear",
                            "${Fold}",
                            '0.63019',
                            '0.63019'
                        ],
                        [
                            "eid83",
                            "scaleY",
                            0,
                            0,
                            "linear",
                            "${computer}",
                            '0.84746',
                            '0.84746'
                        ],
                        [
                            "eid75",
                            "scaleX",
                            0,
                            0,
                            "linear",
                            "${player}",
                            '0.90909',
                            '0.90909'
                        ],
                        [
                            "eid87",
                            "top",
                            0,
                            0,
                            "linear",
                            "${player}",
                            '60px',
                            '60px'
                        ],
                        [
                            "eid18",
                            "top",
                            0,
                            0,
                            "linear",
                            "${Deal}",
                            '334px',
                            '334px'
                        ],
                        [
                            "eid84",
                            "top",
                            0,
                            0,
                            "linear",
                            "${computer}",
                            '70px',
                            '70px'
                        ],
                        [
                            "eid9",
                            "scaleY",
                            0,
                            0,
                            "linear",
                            "${Deal}",
                            '0.63019',
                            '0.63019'
                        ],
                        [
                            "eid81",
                            "left",
                            0,
                            0,
                            "linear",
                            "${player}",
                            '303px',
                            '303px'
                        ],
                        [
                            "eid86",
                            "scaleY",
                            0,
                            0,
                            "linear",
                            "${player}",
                            '0.84746',
                            '0.84746'
                        ],
                        [
                            "eid2",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${Deal}",
                            '0.6',
                            '0.6'
                        ],
                        [
                            "eid71",
                            "scaleX",
                            0,
                            0,
                            "linear",
                            "${computer}",
                            '0.90909',
                            '0.90909'
                        ]
                    ]
                }
            },
            "Deal": {
                version: "5.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.0.375",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            rect: ['0px', '0px', '96px', '60px', 'auto', 'auto'],
                            borderRadius: ['10px', '10px', '10px', '10px'],
                            id: 'btnDeal',
                            stroke: [0, 'rgb(0, 0, 0)', 'none'],
                            type: 'rect',
                            fill: ['rgba(0,0,0,1)']
                        },
                        {
                            type: 'text',
                            rect: ['1px', '1px', '96px', '60px', 'auto', 'auto'],
                            text: 'DEAL',
                            id: 'Deal',
                            textStyle: ['', '', '56px', ''],
                            align: 'center',
                            font: ['Arial, Helvetica, sans-serif', [25, 'px'], 'rgba(255,255,255,1)', '500', 'none', 'normal', 'break-word', 'normal']
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '97px', '61px']
                        }
                    }
                },
                timeline: {
                    duration: 0,
                    autoPlay: true,
                    data: [

                    ]
                }
            },
            "Fold": {
                version: "5.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.0.375",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            rect: ['0px', '0px', '96px', '60px', 'auto', 'auto'],
                            borderRadius: ['10px', '10px', '10px', '10px'],
                            id: 'btnFold',
                            stroke: [0, 'rgb(0, 0, 0)', 'none'],
                            type: 'rect',
                            fill: ['rgba(0,0,0,1)']
                        },
                        {
                            type: 'text',
                            id: 'Text3',
                            textStyle: ['', '', '57px', ''],
                            rect: ['1px', '1px', '96px', '61px', 'auto', 'auto'],
                            align: 'center',
                            font: ['Arial, Helvetica, sans-serif', [30, 'px'], 'rgba(255,255,255,1)', '500', 'none solid rgb(255, 255, 255)', 'normal', 'break-word', 'normal'],
                            opacity: 1,
                            text: 'Fold'
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '97px', '62px']
                        }
                    }
                },
                timeline: {
                    duration: 0,
                    autoPlay: true,
                    data: [

                    ]
                }
            },
            "CardsContainer": {
                version: "5.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.0.375",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            rect: ['0px', '0px', '154px', '236px', 'auto', 'auto'],
                            stroke: [0, 'rgb(0, 0, 0)', 'none'],
                            id: 'Rectangle2',
                            opacity: 1,
                            type: 'rect',
                            fill: ['rgba(0,0,0,0.00)']
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '154px', '236px']
                        }
                    }
                },
                timeline: {
                    duration: 0,
                    autoPlay: true,
                    data: [

                    ]
                }
            },
            "Card": {
                version: "5.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.0.375",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            type: 'rect',
                            id: 'placeholder',
                            symbolName: 'CardsContainer',
                            transform: [[], [], [], ['1.46104', '1.32627']],
                            rect: ['36px', '39px', undefined, undefined, 'auto', 'auto']
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            isStage: 'true',
                            rect: [undefined, undefined, '225px', '313px']
                        }
                    }
                },
                timeline: {
                    duration: 0,
                    autoPlay: false,
                    data: [

                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("BlackJack_edgeActions.js");
})("BlackJack");
