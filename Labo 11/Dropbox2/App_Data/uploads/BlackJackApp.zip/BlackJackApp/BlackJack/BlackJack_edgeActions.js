/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

var stageRef, scoreP, scoreC, rotation, azenP, azenC, gameOver, giveUp, topMargin;
var cards = new Array();


function initGame(){
	console.log("> init game");
	console.log(">   setting defaults");
	scoreP = scoreC = azenP = azenC = 0;
	gameOver = giveUp = false;
	topMargin = 20;
	rotation = -10;
	
	console.log(">      player en computer hun oude kaarten verwijderen");
	stageRef.$("player").children().remove();
	stageRef.$("computer").children().remove();
	
	console.log(">			alle kaarten ophalen en in een array plaatsen");
	$.getJSON("cards.json", function(data){
	console.log(">         cards downloaded");
	
	var l = data.length;
	for(var i = 0; i < l ; i++){
		cards.push(data[i]);
	}
	
	startGame();
	});
}

function startGame(){
	log("Game started");
	console.log(">		Game started");
	
	addCard("computer");
	addCard("player");
}

function addCard(target){
	console.log("> adding card for " + target);
	// random kaart => getal tussen 1 en 52
	var rand = Math.floor(Math.random()*cards.length);
	console.log(">     cardnr: " + rand);
	
	var card = cards[rand];
	// card is een object met 2 properties => zie cards.json
	console.log(">		image: " + card.image + " en zijn waarde " + card.value);
	
	// haal mij de kaart op een bepaalde plaats(rand) en tweede parameter
	// is het antal dat weggenomen moet worden van de geselecteerde kaart
	cards.splice(rand, 1);
	
// dynamisch kaarten aan de container toevoegen
	var cardSymbol = stageRef.createChildSymbol("Card", target);
	cardSymbol.$('placeholder').css({
		"background-image": "url('"+ card.image +"')",
		"background-size" : "100%",
		"background-repeat" : "no-repeat"
	});
	
	if(target == "player")
	{
		var initRotation = 70;
		cardSymbol.getSymbolElement().css({
			"position" : "absolute",
			"left" : "160px",
			"top" : "87px",
			"-webkit-transform-origin" : "50% 400%",
			"transform-origin" : "50% 400%",	
			"-webkit-transform" : "rotate('"+initRotation+ "deg')",
			"-moz-transform" : "rotate('"+initRotation+ "deg')",
			"-o-transform" : "rotate('"+initRotation+ "deg')",
			"-ms-transform" : "rotate('"+initRotation+ "deg')",
			"transform" : "rotate('"+initRotation+ "deg')"					
		});
		
		rotation += 2;
		cardSymbol.getSymbolElement().transition({
			rotate: rotation + "deg",
			y: '-100px'
		}, 500, "snap");
	}
	else
	{
		//computer
		cardSymbol.getSymbolElement().css({
			"position" : "absolute",
			"top" : topMargin + "px",
			"left" : "30px"
		});
		
		topMargin += 60;
	}
	
	}



function log(text){
	stageRef.$("log").html(text);
}

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      Symbol.bindSymbolAction(compId, symbolName, "creationComplete", function(sym, e) {
         // insert code to be run when the symbol is created here
         stageRef = sym;

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "document", "compositionReady", function(sym, e) {
         // insert code to be run when the composition is fully loaded here
         //initGame();
         
         // initGame pas starten als de transit.min.js geladen is
         yepnope({
         	load: "transit/jquery.transit.min.js",
         	complete: initGame
         });

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'Deal'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${btnDeal}", "click", function(sym, e) {
         // insert code for mouse click here
         if(!gameOver)
         {
         	addCard("player");
         }
         else
         {
         	initGame();
         }

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${Deal}", "click", function(sym, e) {
         // insert code for mouse click here
         if(!gameOver)
         {
         	addCard("player");
         }
         else
         {
         	initGame();
         }

      });
      //Edge binding end

   })("Deal");
   //Edge symbol end:'Deal'

   //=========================================================
   
   //Edge symbol: 'Fold'
   (function(symbolName) {   
   
      Symbol.bindElementAction(compId, symbolName, "${btnFold}", "click", function(sym, e) {
         // insert code for mouse click here
         if(!gameOver)
         {
         	addCard("computer");
         }
         else
         {
         	initGame();
         }

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${Text3}", "click", function(sym, e) {
         // insert code for mouse click here
         if(!gameOver)
         {
         	addCard("computer");
         }
         else
         {
         	initGame();
         }

      });
      //Edge binding end

   })("Fold");
   //Edge symbol end:'Fold'

   //=========================================================
   
   //Edge symbol: 'CardsContainer'
   (function(symbolName) {   
   
   })("CardsContainer");
   //Edge symbol end:'CardsContainer'

   //=========================================================
   
   //Edge symbol: 'Card'
   (function(symbolName) {   
   
   })("Card");
   //Edge symbol end:'Card'

})(window.jQuery || AdobeEdge.$, AdobeEdge, "BlackJack");